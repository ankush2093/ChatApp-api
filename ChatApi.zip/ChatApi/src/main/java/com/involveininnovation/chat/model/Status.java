package com.involveininnovation.chat.model;

public enum Status {
    JOIN,
    MESSAGE,
    LEAVE
}
